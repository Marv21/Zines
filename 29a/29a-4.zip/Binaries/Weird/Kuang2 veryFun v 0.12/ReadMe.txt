Kuang2 veryFun
   v0.12

coded by Weird
<weird173@yahoo.com>
http://members.tripod.com/~weird173



This is a small and funy program. With it you can have fun with somebody. You should use it like a internet trojan plugin, but, of course, you can use it on somebody local machine, too.


Here are command line params for 'Kuang2 veryFun':

M "<message>"
show message on the screen.

HS
hide start button from taskbar.

HT
hide taskbar from screen.

SS
show start button.

ST
show taskbar.

KS
kill start button, so it can't be restored until system reboot.

PW <waw_file>
play waw file.

DI
inverts desktop.

DW
make desktop white.

DB
make desktop black.

DC
contract desktop.

DT "<message>"
draw a message on the desktop.

DS <bmp_full_filename>
save current desktop into a bitmap.

IF
randomly moves desktop icons.

ID
delete all desktop icons (until reboot).

WF
randomly moves all desktop windows.

E
exit windows.

CO
eject CD ROM.

CC
close CD ROM.
