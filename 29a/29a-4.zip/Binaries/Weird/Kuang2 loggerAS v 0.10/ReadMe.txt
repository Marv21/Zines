
Kuang2 loggerAS
    v0.10


This trogan logs all target keystrokes and windows manipulation and sends all data back to you. Use it like 'Kuang2 pSender'.

Before infecting somebody you first must setup 'Kuang2 loggerAS'.
Here is switches description:
	Log Windows content - it logs max 512 bytes of every window it can find
	recursive child search - logs *all* childs (not only top childs)
	only edit controls - log only edit fields
	only passwords - log only password fields
	Log extended keys - log keys like <LEFT>, <HOME> etc
	Log caption changes - log caption name changing
	Send every XX days - how many days to wait between sending
	
Note that when 'Log Window content' is checked there will be logger a big amount of data, especially with 'recursive child search' turned on !!! Use it with caution!


IMPORTANT NOTE: I created this trogan because many asked for it. But, I didnt have much time for making it in way I wanted. So I am not satisfy with this version and I only tested it until it works fine. Also, this piece of code is *slow* and not much optimized. So I put myself away from this trogan.


weird
<weird173@yahoo.com>
http://members.tripod.com/~weird173
http://move.to/weird
	