#include <stdio.h>

int main(void)
{
   	printf("X\n");
        close(-11);
        return 0;
}

